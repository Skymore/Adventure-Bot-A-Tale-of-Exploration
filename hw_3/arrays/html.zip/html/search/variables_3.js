var searchData=
[
  ['origin_0',['origin',['../struct_dynamic_array.html#ad67a4916a1a868fb22151258d11eda83',1,'DynamicArray']]]
];
